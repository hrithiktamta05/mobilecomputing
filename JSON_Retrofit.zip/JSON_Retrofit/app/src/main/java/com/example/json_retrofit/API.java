package com.example.json_retrofit;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;

public class API {
    static String BASE_URL = "https://api.github.com/";

    @GET("users")
    Call<List<User>> getRecords(){
        return null;
    }
}
