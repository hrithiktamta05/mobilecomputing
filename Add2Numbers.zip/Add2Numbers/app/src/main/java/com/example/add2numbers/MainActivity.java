package com.example.add2numbers;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText editText1, editText2;
    private Button button;
    private TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText1 = findViewById(R.id.editTextNum1);
        editText2 = findViewById(R.id.editTextNum2);
        button = findViewById(R.id.buttonAdd);
        textView = findViewById(R.id.textViewResult);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String str1 = editText1.getText().toString();
                String str2 = editText2.getText().toString();

                if(!str1.isEmpty() && !str2.isEmpty()){
                    int num1 = Integer.parseInt(str1);
                    int num2 = Integer.parseInt(str2);

                    int sum = num1 + num2;

                    Toast.makeText(MainActivity.this,"Sum : "+sum,Toast.LENGTH_SHORT).show();
                }else {
                    Toast.makeText(MainActivity.this,"Please enter both numbers",Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}