import 'package:flutter/material.dart';
void main() {
  runApp(MyApp());
}
class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: FirstScreen(),
    );
  }
}
class FirstScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('This is the First Screen',style: TextStyle(
          color: Colors.indigo,fontSize: 25.5,fontWeight: FontWeight.bold
        ),),
      ),
      body: Center(
        child: ElevatedButton(
          onPressed: () {
            // Navigate to the second screen when the button is pressed
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => SecondScreen()),
            );
          },
          child: Text('Navigate to Second Screen',style: TextStyle(
              color: Colors.indigo,fontSize: 25.5,fontWeight: FontWeight.bold
          ),),
        ),
      ),
    );
  }
}
class SecondScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Welcome to the Second Screen',style: TextStyle(
          color: Colors.indigo,fontSize: 25.5,fontWeight: FontWeight.bold
        ),),
      ),
      body: Center(
        child: ElevatedButton(
          onPressed: () {
            // Navigate back to the first screen when the button is pressed
            Navigator.pop(context);
          },
          child: Text('Navigate back to First Screen',style: TextStyle(
              color: Colors.indigo,fontSize: 25.5,fontWeight: FontWeight.bold
          ),),
        ),
      ),
    );
  }
}
