package com.example.flutter_intent;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
