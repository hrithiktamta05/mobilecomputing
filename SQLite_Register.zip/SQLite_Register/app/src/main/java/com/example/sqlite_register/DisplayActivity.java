package com.example.sqlite_register;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
public class DisplayActivity extends AppCompatActivity {

    private DatabaseHelper databaseHelper;
    private TextView textViewUsers;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display);

        textViewUsers = findViewById(R.id.textViewUsers);
        databaseHelper = new DatabaseHelper(this);

        displayUsers();
    }

    private void displayUsers() {
        StringBuilder usersStringBuilder = new StringBuilder();

        Cursor cursor = databaseHelper.getAllUsers();

        if (cursor.moveToFirst()) {
            do {
                @SuppressLint("Range") String name = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_NAME));
                @SuppressLint("Range") String email = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_EMAIL));

                usersStringBuilder.append("Name: ").append(name).append("\n");
                usersStringBuilder.append("Email: ").append(email).append("\n\n");
            } while (cursor.moveToNext());
        }

        cursor.close();
        textViewUsers.setText(usersStringBuilder.toString());
    }
}