package com.example.crud_sqlite;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
public class MainActivity extends AppCompatActivity {
    DatabaseHelper databaseHelper;
    EditText Id,Name, Surname, marks;
    Button Add, btnView, search,btnUpdate, btnDelete, btnClear;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        databaseHelper=new DatabaseHelper(this);
        Id=findViewById(R.id.et_id);
        Name=findViewById(R.id.et_name);
        Surname=findViewById(R.id.et_surname);
        marks=findViewById(R.id.et_marks);
        Add=findViewById(R.id.btn_add);
        btnView=findViewById(R.id.btn_view);
        search=findViewById(R.id.btn_search);
        btnUpdate=findViewById(R.id.btn_update);
        btnDelete=findViewById(R.id.btn_delete);
        btnClear=findViewById(R.id.btn_clear);
        Add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(databaseHelper.insertData(Name.getText().toString(),Surname.getText().toString(),marks.getText().toString()))
                    Toast.makeText(MainActivity.this, "Data inserted successfully..", Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(MainActivity.this, "Failed to insert data.", Toast.LENGTH_SHORT).show();
            }
        });
        btnView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Cursor result=databaseHelper.getAllStudents();
                if(result.getCount()==0){
                    Toast.makeText(MainActivity.this, "No entry exists.",
                            Toast.LENGTH_SHORT).show();
                    return;
                }
                StringBuffer buffer=new StringBuffer();
                while(result.moveToNext()){
                    buffer.append("ID "+result.getString(0)+"\n");
                    buffer.append("Name "+result.getString(1)+"\n");
                    buffer.append("Surname "+result.getString(2)+"\n");
                    buffer.append("Marks "+result.getString(3)+"\n");
                }
                AlertDialog.Builder builder=new
                        AlertDialog.Builder(MainActivity.this);
                builder.setCancelable(true);
                builder.setMessage(buffer).toString();
                builder.setTitle("Student Data");
                builder.show();
            }
        });
        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Cursor
                        result=databaseHelper.getStudentById(Integer.parseInt(Id.getText().toString()));
                if(result.getCount()==0){
                    Toast.makeText(MainActivity.this, "No entry exists.",
                            Toast.LENGTH_SHORT).show();
                    return;
                }
                StringBuffer buffer=new StringBuffer();
                while(result.moveToNext()){
                    buffer.append("ID "+result.getString(0)+"\n");
                    buffer.append("Name "+result.getString(1)+"\n");
                    buffer.append("Surname "+result.getString(2)+"\n");
                    buffer.append("Marks "+result.getString(3)+"\n");
                }
                AlertDialog.Builder builder=new
                        AlertDialog.Builder(MainActivity.this);
                builder.setCancelable(true);
                builder.setMessage(buffer).toString();
                builder.setTitle("Student " +Id.getText().toString()+ "Data");
                builder.show();
                result.moveToFirst();
                Name.setText(result.getString(1));
                Surname.setText(result.getString(2));
                marks.setText("" + result.getString(3));
            }
        });
        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                databaseHelper.updateData(Id.getText().toString(),Name.getText().toString(),Surname.getText().toString(),marks.getText().toString());
                Toast.makeText(MainActivity.this, "Student "+Id.getText().toString()+" Updated.", Toast.LENGTH_SHORT).show();
            }
        });
        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(databaseHelper.deleteStudent(Id.getText().toString())>0)
                    Toast.makeText(MainActivity.this, "Student "+
                            Id.getText().toString()+ " Deleted.", Toast.LENGTH_SHORT).show();;
            }
        });
        btnClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Id.getText().clear();
                Name.getText().clear();
                Surname.getText().clear();
                marks.getText().clear();
            }
        });
    }
}