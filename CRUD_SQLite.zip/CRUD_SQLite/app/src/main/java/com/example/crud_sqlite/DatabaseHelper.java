package com.example.crud_sqlite;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import androidx.annotation.Nullable;
public class DatabaseHelper extends SQLiteOpenHelper {
    private SQLiteDatabase sqLiteDatabase;
    public static final String DATABASE_NAME="Student.db";
    public static final String TABLE_NAME="Student";
    public static final String COL_2="NAME";
    public static final String COL_3="SURNAME";
    public DatabaseHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, 1);
    }
    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("create table "+TABLE_NAME+"(ID Integer Primary key Autoincrement,NAME Text,SURNAME Text,MARKS integer)");
    }
    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("drop table if exists "+TABLE_NAME);
        onCreate(sqLiteDatabase);
    }
    public boolean insertData(String name,String surname,String marks){
        sqLiteDatabase=getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put(COL_2,name);
        contentValues.put(COL_3,surname);
        contentValues.put("MARKS",marks);
        long result=sqLiteDatabase.insert(TABLE_NAME,null,contentValues);
        if(result==-1)
            return false;
        else
            return true;
    }
    public Cursor getAllStudents(){
        sqLiteDatabase=getReadableDatabase();
        String query="select * from "+TABLE_NAME;
        return sqLiteDatabase.rawQuery(query,null);
    }
    public Cursor getStudentById(Integer id){
        sqLiteDatabase=getReadableDatabase();
        String query="select * from " +TABLE_NAME + " where ID = " + id;
        return sqLiteDatabase.rawQuery(query,null);
    }
    public void updateData(String id, String name, String surname, String marks){
        sqLiteDatabase=getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put("ID", id);
        contentValues.put(COL_2, name);
        contentValues.put(COL_3, surname);
        contentValues.put("MARKS", marks);
        sqLiteDatabase.update(TABLE_NAME,contentValues,"ID=? ",new String[]{id});
    }
    public Integer deleteStudent(String id){
        sqLiteDatabase=getWritableDatabase();
        return sqLiteDatabase.delete(TABLE_NAME,"ID=? ",new String[]{id});
    }
}