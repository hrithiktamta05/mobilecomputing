package com.example.bluetoothapp;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.bluetooth.BluetoothAdapter;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button btnEnableDisable;
    BluetoothAdapter bluetooth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnEnableDisable = findViewById(R.id.btn_en_dis_bluetooth);

        bluetooth = BluetoothAdapter.getDefaultAdapter();

        if (bluetooth == null) {
            Toast.makeText(this, "Bluetooth not Supported!", Toast.LENGTH_SHORT).show();
            btnEnableDisable.setEnabled(false);
            return;
        }
        setButtonLabel();
        btnEnableDisable.setOnClickListener(view -> {

            if (bluetooth.isEnabled()) {
                if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                    // TODO: Consider calling
                    //    ActivityCompat#requestPermissions
                    // here to request the missing permissions, and then overriding
                    //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                    //                                          int[] grantResults)
                    // to handle the case where the user grants the permission. See the documentation
                    // for ActivityCompat#requestPermissions for more details.
                    return;
                }
                bluetooth.disable();
                Toast.makeText(this, "Bluetooth Turned Off...",
                        Toast.LENGTH_SHORT).show();
            }

            else {
                bluetooth.isEnabled();
                Toast.makeText(this, "Bluetooth Turned On...",
                        Toast.LENGTH_SHORT).show();
            }

            setButtonLabel();
        });
    }

    private void setButtonLabel() {
        if(bluetooth.isEnabled())
            btnEnableDisable.setText("Disable Bluetooth");
        else
            btnEnableDisable.setText("Enable Bluetooth");
    }
}









// MainActivity.java
//import android.annotation.SuppressLint;
//import android.bluetooth.BluetoothAdapter;
//import android.content.Intent;
//import android.os.Bundle;
//import android.view.View;
//import android.widget.Button;
//import androidx.appcompat.app.AppCompatActivity;

//public class MainActivity extends AppCompatActivity {
//
//
//    private BluetoothAdapter bluetoothAdapter;
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_main);
//
//        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
//
//        Button btnEnableBluetooth = findViewById(R.id.btnEnableBluetooth);
//        Button btnDisableBluetooth = findViewById(R.id.btnDisableBluetooth);
//
//        btnEnableBluetooth.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                enableBluetooth();
//            }
//        });
//
//        btnDisableBluetooth.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                disableBluetooth();
//            }
//        });
//    }
//
//    @SuppressLint("MissingPermission")
//    private void enableBluetooth() {
//        if (bluetoothAdapter != null) {
//            if (!bluetoothAdapter.isEnabled()) {
//                Intent enableBluetoothIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
//                startActivityForResult(enableBluetoothIntent,1);
//            }
//        }
//    }
//
//    @SuppressLint("MissingPermission")
//    private void disableBluetooth() {
//        if (bluetoothAdapter != null) {
//            if (bluetoothAdapter.isEnabled()) {
//                bluetoothAdapter.disable();
//            }
//        }
//    }



