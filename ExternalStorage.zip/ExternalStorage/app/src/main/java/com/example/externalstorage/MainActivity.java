package com.example.externalstorage;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;

public class MainActivity extends AppCompatActivity {

    private TextView textView;
    private EditText editText;
    private Button btnRead, btnWrite;

    private String FILENAME = "NMITD.txt";
    private String filepath = "MyFileStorage";
    private String data = "";
    private File textfile;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textView = findViewById(R.id.textView);
        editText = findViewById(R.id.edittext);
        btnRead = findViewById(R.id.button);
        btnWrite = findViewById(R.id.button2);
        
        if(!isExternalStorageAvailable()||isExternalStorageReadOnly()){
            btnWrite.setEnabled(false);
        }else {
            textfile = new File(getExternalFilesDir(filepath),FILENAME);
        }
        getDir();
        btnWrite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                data = editText.getText().toString();
                try {
                    FileOutputStream fileOutputStream = new FileOutputStream(textfile);
                    fileOutputStream.write(data.getBytes());
                    editText.getText().clear();
                    Toast.makeText(getApplicationContext(),"Data written to external storage successfully",Toast.LENGTH_LONG).show();
                    fileOutputStream.close();

                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        });

        btnRead.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    FileInputStream fileInputStream = new FileInputStream(textfile);
                    InputStreamReader inputStreamReader = new InputStreamReader(fileInputStream);
                    BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
                    StringBuilder stringBuilder = new StringBuilder();
                    String line;
                    while((line=bufferedReader.readLine())!=null){
                        stringBuilder.append("\n").append(line);
                    }
                    editText.setText(data);
                    Toast.makeText(getApplicationContext(),"Data Loaded",Toast.LENGTH_LONG).show();
                    fileInputStream.close();
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        });
    }

    private void getDir() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("External File Dir : ").append(getExternalFilesDir(filepath).getAbsolutePath());
        textView.setText(stringBuilder.toString());
    }

    private boolean isExternalStorageReadOnly() {
        String exread = Environment.getExternalStorageState();
        return Environment.MEDIA_MOUNTED_READ_ONLY.equals(exread);
    }

    private boolean isExternalStorageAvailable() {
        String exstorage = Environment.getExternalStorageState();
        return Environment.MEDIA_MOUNTED.equals(exstorage);
    }
}