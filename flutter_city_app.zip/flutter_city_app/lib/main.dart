import 'package:flutter/material.dart';
void main() => runApp(City());

class City extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return UserCity();
  }
}
class UserCity extends State<City> {
  @override
  String cityName="";
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Stateful Widget',
      home: Scaffold(
        appBar: AppBar(
          title: Text('Stateful Widget app'),
        ),
        body: Container(
          margin: EdgeInsets.all(20.0),
          child: Column(
            children: <Widget>[
              TextField(onChanged: (String userInput){
                setState(() {
                  cityName=userInput;
                });
              },),
              Padding(padding: EdgeInsets.all(30.0),
                  child: Text('Your favourite city is $cityName',style: TextStyle(fontSize: 20.0),
                  ))
            ],
          ),
        ),
      ),
    );
  }
}
