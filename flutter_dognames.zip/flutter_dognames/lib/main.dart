import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Dog App',
      home: Scaffold(
        backgroundColor: Colors.black,
        appBar: AppBar(
          backgroundColor: Colors.white70,
          title: Text('Labrador'),
        ),
        body: Center(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const DogName('Timoothy'),
              const SizedBox(height: 10.0,),
              const DogName('Sphere'),
              const SizedBox(height: 10.0,),
              const DogName('Raju'),
              const SizedBox(height: 10.0,),

            ],
          ),
        ),
        floatingActionButton: FloatingActionButton(
          child: Icon(Icons.add),onPressed: (){},
        ),
        drawer: Drawer(child: Text('Demo'),),
        bottomNavigationBar: BottomNavigationBar(
          items: [
            BottomNavigationBarItem(icon: Icon(Icons.home),label: 'Home'),
            BottomNavigationBarItem(icon: Icon(Icons.alarm),label: 'Alarm'),
          ],
        ),
      ),

    );
  }
}

class DogName extends StatelessWidget{
  final String name;
  const DogName(this.name);
  @override
  Widget build(BuildContext context) {
    return DecoratedBox(decoration: const BoxDecoration(color: Colors.deepOrangeAccent),
    child: Padding(
      padding: EdgeInsets.all(10.0),
      child: Text(
        name
      ),
    ),);

  }

}

