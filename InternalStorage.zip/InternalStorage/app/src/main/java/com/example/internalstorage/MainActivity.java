package com.example.internalstorage;

import static android.provider.Telephony.Mms.Part.FILENAME;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;

public class MainActivity extends AppCompatActivity {

    private TextView textView;
    private EditText editText;
    private Button btnRead, btnWrite;
    private String FILENAME = "demo.txt";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textView = findViewById(R.id.textView);
        editText = findViewById(R.id.edittext);
        btnRead = findViewById(R.id.btn1);
        btnWrite = findViewById(R.id.btn2);
        btnWrite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String data = editText.getText().toString();
                try {
                    FileOutputStream fileOutputStream = openFileOutput(FILENAME,MODE_PRIVATE);
                    fileOutputStream.write(data.getBytes());
                    Toast.makeText(getApplicationContext(),"Data written successfully",Toast.LENGTH_LONG).show();
                    editText.getText().clear();
                    fileOutputStream.close();
                }catch(Exception e){
                    e.printStackTrace();
                }
            }
        });

        btnRead.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    FileInputStream fileInputStream = openFileInput(FILENAME);
                    InputStreamReader inputStreamReader = new InputStreamReader(fileInputStream);
                    BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
                    StringBuilder stringBuilder = new StringBuilder();
                    String line;
                    while((line=bufferedReader.readLine())!=null){
                        stringBuilder.append("\n").append(line);
                    }
                    stringBuilder.deleteCharAt(0);
                    textView.setText(stringBuilder);
                    Toast.makeText(getApplicationContext(),"Data loaded successfully",Toast.LENGTH_LONG).show();
                    fileInputStream.close();

                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        });
        getDir();
    }

    private void getDir() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Cache Directory : ").append(getCacheDir().getAbsolutePath()).append("\n File Directory : ").append(getFilesDir().getAbsolutePath());
        textView.setText(stringBuilder.toString());
    }
}