package com.example.sharedpref;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class HomeScreen extends AppCompatActivity {
    TextView textView;
    Button button;
    SharedPreferences pref;
    Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_screen);
        textView = findViewById(R.id.txtdisplay);
        button = findViewById(R.id.btn_logout);
        pref = getSharedPreferences("user_details",MODE_PRIVATE);
        textView.setText("Hello, "+pref.getString("username",null));
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences.Editor editor = pref.edit();
                editor.clear();
                editor.commit();
                intent = new Intent(HomeScreen.this, MainActivity.class);
                startActivity(intent);

            }
        });
    }
}