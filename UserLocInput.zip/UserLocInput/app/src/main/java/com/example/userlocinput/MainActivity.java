package com.example.userlocinput;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private EditText editTextLatitude;
    private EditText editTextLongitude;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editTextLatitude = findViewById(R.id.editTextLatitude);
        editTextLongitude = findViewById(R.id.editTextLongitude);
        Button btnshowlocation = findViewById(R.id.btnShowLocation);
        btnshowlocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showLocationMap();
            }
        });

    }

    private void showLocationMap() {
        String latitudestr = editTextLatitude.getText().toString().trim();
        String longitudestr = editTextLongitude.getText().toString().trim();

        if(!latitudestr.isEmpty() && !longitudestr.isEmpty()){
            double latitude = Double.parseDouble(latitudestr);
            double longitude = Double.parseDouble(longitudestr);

            Uri uri = Uri.parse("geo:"+latitude+","+longitude+"?q="+latitude+","+longitude);
            Intent intent = new Intent(Intent.ACTION_VIEW,uri);
            intent.setPackage("com.google.andriod.apps.maps");

            if(intent.resolveActivity(getPackageManager()) != null){
                startActivity(intent);
            }else {
                Toast.makeText(MainActivity.this,"Google Maps not installed on the device",Toast.LENGTH_LONG).show();
            }
        }else {
            Toast.makeText(MainActivity.this,"Please enter both latitude and longitude",Toast.LENGTH_LONG).show();
        }
    }
}