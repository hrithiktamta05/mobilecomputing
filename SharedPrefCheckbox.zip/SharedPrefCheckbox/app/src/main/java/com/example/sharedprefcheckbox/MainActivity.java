package com.example.sharedprefcheckbox;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button login;
    EditText name,pwd;
    CheckBox checkBox;
    SharedPreferences pref;
    Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        login = findViewById(R.id.button);
        name = findViewById(R.id.edit1);
        pwd = findViewById(R.id.edit2);
        checkBox = findViewById(R.id.checkBox);
        pref = getSharedPreferences("user_details",MODE_PRIVATE);
        intent = new Intent(MainActivity.this, HomeScreen.class);
        if(pref.contains("username") && pref.contains("password")){
            startActivity(intent);
        }
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = name.getText().toString();
                String password = pwd.getText().toString();
                if(username.equals("pranayyy.g") && password.equals("123456") &&
                        checkBox.isChecked()){
                    SharedPreferences.Editor editor = pref.edit();
                    editor.putString("username",username);
                    editor.putString("password",password);
                    editor.commit();
                    Toast.makeText(getApplicationContext() , "Login Successful", Toast.LENGTH_LONG).show();
                    startActivity(intent);
                }else if (username.equals("pranayyy.g") && password.equals("123456")) {
                    Toast.makeText(getApplicationContext() , "Login Successful", Toast.LENGTH_LONG).show();
                    startActivity(intent);
                }else{
                    Toast.makeText(getApplicationContext() , "Invalid credentials", Toast.LENGTH_LONG).show();
                }


            }
        });


    }


}
