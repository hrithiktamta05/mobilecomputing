package com.example.frameanimation;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    ImageView img;
    Button btnStartStop;
    AnimationDrawable animation;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        img = findViewById(R.id.img);
        btnStartStop = findViewById(R.id.btn_start_stop);
// fetching animation drawable from image view
        animation = (AnimationDrawable) img.getDrawable();
// starting and stopping animation on button click
        btnStartStop.setOnClickListener(view -> {
// if running then stop
            if (animation.isRunning()) {
                animation.stop();
                btnStartStop.setText("Start");
                return;
            }
// else start animation
            animation.start();
            btnStartStop.setText("Stop");
        });
    }


}