package com.example.jsonparsinghttp;

import androidx.appcompat.app.AppCompatActivity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
public class MainActivity extends AppCompatActivity {
    Button btnFetchData;
    TextView resultView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnFetchData = findViewById(R.id.btn_fetch_data);
        btnFetchData.setOnClickListener(view -> {
            Users users = new Users();
            users.execute();
        });
        resultView = findViewById(R.id.result_view);
    }
    // class which fetch data from API in separate thread
    class Users extends AsyncTask<String, String, String> {
        @Override
        protected String doInBackground(String... strings) {
            try {
                URL url = new URL("https://api.github.com/users");
                HttpURLConnection connection = (HttpURLConnection)
                        url.openConnection();
                connection.connect();
                InputStream stream = connection.getInputStream();
                BufferedReader reader = new BufferedReader(new
                        InputStreamReader(stream));
                StringBuffer buffer = new StringBuffer();
                String line;
                while((line = reader.readLine()) != null) {
                    buffer.append(line).append("\n");
                }
                return buffer.toString();
            }
            catch (IOException ex) {
                Toast.makeText(getApplicationContext(), ex.getMessage(),
                        Toast.LENGTH_SHORT).show();
            }
            return "";
        }
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            btnFetchData.setEnabled(false);
        }
        @Override
        protected void onProgressUpdate(String... values) {
            super.onProgressUpdate(values);
            resultView.setText("Loading..." + values + "% done");
        }
        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            resultView.setText(s);
            btnFetchData.setEnabled(true);
        }
    }
}