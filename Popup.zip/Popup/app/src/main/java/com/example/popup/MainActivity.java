package com.example.popup;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.option,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if(id==R.id.search){
            Toast.makeText(getApplicationContext(), "Search Clicked", Toast.LENGTH_SHORT).show();
        } else if (id == R.id.newgrp) {
            Toast.makeText(getApplicationContext(), "New Group Clicked", Toast.LENGTH_SHORT).show();
        } else if (id == R.id.settings) {
            Toast.makeText(getApplicationContext(), "Settings Cliked", Toast.LENGTH_SHORT).show();
        } else if (id == R.id.chat) {
            Toast.makeText(getApplicationContext(), "Chat Clicked", Toast.LENGTH_SHORT).show();
        } else if (id == R.id.acc) {
            Toast.makeText(getApplicationContext(), "Account Clicked", Toast.LENGTH_SHORT).show();
        } else if (id == R.id.noti) {
            Toast.makeText(getApplicationContext(), "Notifications Clicked", Toast.LENGTH_SHORT).show();
        }
        return super.onOptionsItemSelected(item);
    }
}