package com.example.loginpage;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText name, pwd;
    CheckBox rememberme;
    Button login;
    SharedPreferences sharedPreferences;
    Intent intent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        name = findViewById(R.id.edittext1);
        pwd = findViewById(R.id.edittext2);
        rememberme = findViewById(R.id.remember);
        login = findViewById(R.id.btn);
        sharedPreferences = getSharedPreferences("user_credentials",MODE_PRIVATE);
        intent = new Intent(MainActivity.this, MainActivity2.class);
        if(sharedPreferences.contains("username") && sharedPreferences.contains("password")){
            startActivity(intent);
        }
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = name.getText().toString();
                String password = pwd.getText().toString();
                if(username.equals("Stark") && password.equals("123456") && rememberme.isChecked()){
                    SharedPreferences.Editor myEditor = sharedPreferences.edit();
                    myEditor.putString("username",username);
                    myEditor.putString("password",password);
                    myEditor.apply();
                    Toast.makeText(getApplicationContext(),"Login Successfull",Toast.LENGTH_LONG).show();
                    startActivity(intent);
                } else if (username.equals("Stark") && password.equals("123456")) {
                    Toast.makeText(getApplicationContext(),"Login Successfull",Toast.LENGTH_LONG).show();
                    startActivity(intent);
                    
                }else {
                    Toast.makeText(getApplicationContext(),"Invalid Credentials",Toast.LENGTH_LONG).show();
                }
            }
        });
    }
}