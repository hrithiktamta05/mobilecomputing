package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Bundle;
//import android.view.View;

public class MainActivity extends AppCompatActivity {
    MediaPlayer mp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        findViewById(R.id.Play).setOnClickListener(view -> {
            if(mp==null){
                mp=MediaPlayer.create(getApplicationContext(),R.raw.song);
            }
            mp.start();
        });
        findViewById(R.id.Pause).setOnClickListener(view -> {
            if(mp!=null){
                mp.pause();
            }
        });
        findViewById(R.id.Stop).setOnClickListener(view -> {
            if(mp!=null){
                mp.stop();
            }
        });
    }
}