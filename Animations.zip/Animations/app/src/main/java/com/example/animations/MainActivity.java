package com.example.animations;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    ImageView bird;
    Animation animation;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bird = findViewById(R.id.bird);
    }
    public void clockwise(View view) {
        animation = AnimationUtils.loadAnimation(MainActivity.this,R.anim.rotate_clockwise);
        bird.startAnimation(animation);
        Toast.makeText(this, "Rotating Clockwise...",
                Toast.LENGTH_SHORT).show();
    }

    public void antiClockwise(View view) {
        animation = AnimationUtils.loadAnimation(MainActivity.this,
                R.anim.rotate_anticlockwise);
        bird.startAnimation(animation);
        Toast.makeText(this, "Rotating Anti-Clockwise...",
                Toast.LENGTH_SHORT).show();
    }

    public void expand(View view) {
        animation = AnimationUtils.loadAnimation(MainActivity.this,
                R.anim.expand);
        bird.startAnimation(animation);
        Toast.makeText(this, "Expanding...", Toast.LENGTH_SHORT).show();
    }

    public void shrink(View view) {
        animation = AnimationUtils.loadAnimation(MainActivity.this,
                R.anim.shrink);
        bird.startAnimation(animation);
        Toast.makeText(this, "Shrinking Scaling...", Toast.LENGTH_SHORT).show();
    }

    public void slideL2R(View view) {
        animation = AnimationUtils.loadAnimation(MainActivity.this,
                R.anim.slide_right);
        bird.startAnimation(animation);
        Toast.makeText(this, "Sliding Left to Right...",
                Toast.LENGTH_SHORT).show();
    }

    public void slideT2B(View view) {
        animation = AnimationUtils.loadAnimation(MainActivity.this,
                R.anim.slide_bottom);
        bird.startAnimation(animation);
        Toast.makeText(this, "Sliding Top to Bottom...",
                Toast.LENGTH_SHORT).show();
    }

    public void slideR2L(View view) {
        animation = AnimationUtils.loadAnimation(MainActivity.this,
                R.anim.slide_left);
        bird.startAnimation(animation);
        Toast.makeText(this, "Sliding Right to Left...",
                Toast.LENGTH_SHORT).show();
    }

    public void slideB2T(View view) {
        animation = AnimationUtils.loadAnimation(MainActivity.this,
                R.anim.slide_top);
        bird.startAnimation(animation);
        Toast.makeText(this, "Sliding Bottom to Top...",
                Toast.LENGTH_SHORT).show();
    }

    public void fadeIn(View view) {
        animation = AnimationUtils.loadAnimation(MainActivity.this,
                R.anim.fade_in);
        bird.startAnimation(animation);
        Toast.makeText(this, "Fading In...", Toast.LENGTH_SHORT).show();
    }

    public void fadeOut(View view) {
        animation = AnimationUtils.loadAnimation(MainActivity.this,
                R.anim.fade_out);
        bird.startAnimation(animation);
        Toast.makeText(this, "Fading Out...", Toast.LENGTH_SHORT).show();
    }

    public void expandWithRotation(View view) {
        animation = AnimationUtils.loadAnimation(MainActivity.this,
                R.anim.expand_with_rotation);
        bird.startAnimation(animation);
        Toast.makeText(this, "Expanding with Rotation...",
                Toast.LENGTH_SHORT).show();
    }
    public void slideWithFadeIn(View view) {
        animation = AnimationUtils.loadAnimation(MainActivity.this,
                R.anim.slide_with_fade);
        bird.startAnimation(animation);
        Toast.makeText(this, "Sliding with Fade In...",
                Toast.LENGTH_SHORT).show();
    }
    public void clearAnimation(View view) {
        bird.clearAnimation();
        Toast.makeText(this, "Animation Cleared...",
                Toast.LENGTH_SHORT).show();
    }

}