package com.example.json_volley;

// MainActivity.java
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {

    private Button btnFetchData;
    private TextView tvResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnFetchData = findViewById(R.id.btn_fetch_data);
        tvResult = findViewById(R.id.result_view);

        btnFetchData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fetchData();
            }
        });
    }

    private void fetchData() {
        // Replace the URL with your API endpoint
        String url = "https://api.github.com/users";

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(
                Request.Method.GET,
                url,
                null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        parseData(response);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        tvResult.setText("Error fetching data");
                    }
                });

        // Add the request to the RequestQueue
        Volley.newRequestQueue(this).add(jsonObjectRequest);
    }

    private void parseData(JSONObject response) {
        try {
            // Assuming the response is an array of users
            // Modify this part based on your actual JSON structure
            StringBuilder resultText = new StringBuilder();

            for (int i = 0; i < response.length(); i++) {
                JSONObject user = response.getJSONObject("i");
                String login = user.getString("login");
                String url = user.getString("url");

                resultText.append("Login: ").append(login).append("\n");
                resultText.append("URL: ").append(url).append("\n\n");
            }

            tvResult.setText(resultText.toString());

        } catch (JSONException e) {
            tvResult.setText("Error parsing JSON");
            e.printStackTrace();
        }
    }
}
