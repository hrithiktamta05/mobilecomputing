package com.example.wifiapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button btnEnableDisableWifi;
    WifiManager wifiManager;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnEnableDisableWifi = findViewById(R.id.btn_en_dis_wifi);
        wifiManager = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
        btnEnableDisableWifi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(wifiManager.isWifiEnabled()){
                    wifiManager.setWifiEnabled(false);
                    btnEnableDisableWifi.setText("Enable Wifi");
                    Toast.makeText(MainActivity.this,"Wifi Disabled",Toast.LENGTH_SHORT).show();

                }else {
                    wifiManager.setWifiEnabled(true);
                    btnEnableDisableWifi.setText("Disable Wifi");
                    Toast.makeText(MainActivity.this,"Wifi Enabled",Toast.LENGTH_SHORT).show();
                }
            }
        });



    }


}