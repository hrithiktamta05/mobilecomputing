package com.example.drawgraphics;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId() == R.id.drawLine){
            DrawLine drawLine = new DrawLine(this);
            setContentView(drawLine);
        } else if (item.getItemId() == R.id.drawRectangle){
            DrawRectangle drawRectangle = new DrawRectangle(this);
            setContentView(drawRectangle);
        } else if (item.getItemId() == R.id.drawCircle) {
            setContentView(new DrawCircle(this));
        } else if (item.getItemId() == R.id.drawArc) {
            setContentView(new DrawArc(this));
        } else if (item.getItemId() == R.id.drawImage) {
            setContentView(new DrawImg(this));
        }

        return super.onOptionsItemSelected(item);
    }
}