package com.example.drawgraphics;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;

public class DrawCircle extends View {
    Paint paint = new Paint();
    public DrawCircle(Context context) {
        super(context);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        paint.setStrokeWidth(5);
        paint.setColor(Color.GREEN);
        canvas.drawCircle(200,200,150,paint);
    }
}
