package com.example.drawgraphics;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;

public class DrawArc extends View {
    Paint paint = new Paint();

    public DrawArc(Context context) {
        super(context);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        paint.setStrokeWidth(5);
        paint.setColor(Color.BLUE);
        canvas.drawArc(50,200,400,400,30,100,true,paint);
        canvas.drawArc(50,450,900,900,30,100,false,paint);
    }
}
