package com.example.drawgraphics;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;

public class DrawImg extends View {
    Paint paint = new Paint();

    public DrawImg(Context context) {
        super(context);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        Bitmap bitmap = BitmapFactory.decodeResource(getResources(),R.drawable.abc);
        canvas.drawBitmap(bitmap,1000,1000,paint);
    }
}
