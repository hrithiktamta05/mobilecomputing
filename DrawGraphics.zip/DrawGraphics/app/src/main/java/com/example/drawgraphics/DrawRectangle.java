package com.example.drawgraphics;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;

public class DrawRectangle extends View {
    Paint paint = new Paint();
    public DrawRectangle(Context context) {
        super(context);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        paint.setStrokeWidth(5);
        paint.setColor(Color.BLUE);
        canvas.drawRect(30,30,500,200,paint);
    }
}
