package com.example.reversegeocoding;

import android.location.Location;

import org.jetbrains.annotations.NotNull;

public interface LocationListener {
    public void onLocationChanged(@NotNull Location location);
}
