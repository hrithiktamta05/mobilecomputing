package com.example.linearlayoutdesign;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private EditText editText;
    private TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        findViewById(R.id.editTextTo).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                textView = findViewById(R.id.text1);
                textView.setVisibility(View.INVISIBLE);
            }
        });

        /*editText.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if(!hasFocus){
                    textView.setVisibility(View.VISIBLE);
                }
            }
        });*/
    }
}